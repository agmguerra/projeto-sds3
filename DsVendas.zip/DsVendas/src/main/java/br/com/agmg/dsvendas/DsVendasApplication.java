package br.com.agmg.dsvendas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DsVendasApplication {

	public static void main(String[] args) {
		SpringApplication.run(DsVendasApplication.class, args);
	}

}
