package br.com.agmg.dsvendas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DsVendasApplicationTests {

	@Test
	void contextLoads() {
	}

}
